using System.Security.Cryptography.X509Certificates;
//rohan
namespace player.model;
public class player{
    public player(){}
     public int id { get; set;}
     
     public String name { get; set;}
     public String city { get; set;}

}
