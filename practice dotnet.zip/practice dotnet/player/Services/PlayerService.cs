namespace players.service;
using player.model;
using player.repo;
public class PlayerService : IPlayerService{
    public List<player> GetAll(){
        
        MySqldbManager mgr = new MySqldbManager();
       
        return  mgr.GetAll();
    }

    public player AddNew(player p){
        MySqldbManager mgr = new MySqldbManager();
        return mgr.AddNew(p);
    }

    public player Update(player p){
        MySqldbManager mgr = new MySqldbManager();
        return mgr.Update(p);
    }

    public player Delete(int id){
         MySqldbManager mgr = new MySqldbManager();
        return mgr.Delete(id);
    }
}