namespace players.service;
using player.model;
public interface IPlayerService{
    public List<player> GetAll();

    public player AddNew(player p);

    public player Update(player p);

    public player Delete(int id);

}