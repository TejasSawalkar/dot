namespace player.repo;

using MySql.Data.MySqlClient;

using player.model;
public class MySqldbManager{
    public MySqldbManager(){}
    public List<player>GetAll(){
        List<player> players=new List<player>();
        MySqlConnection con=new MySqlConnection();
        
        con.ConnectionString=@"server=localhost; port=3306; user=root; password=admin123 ; database=testdb" ;
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection=con;
        cmd.CommandText = "select * from player";
        try{
            con.Open();
            MySqlDataReader reader=cmd.ExecuteReader();
            while(reader.Read()){
                int id = int.Parse(reader["id"].ToString());
                string? name = reader["name"].ToString();
                String? city = reader["city"].ToString();

                player p=new player();
                p.id = id;
                p.name = name;
                p.city = city;

                players.Add(p);

            }

        }catch(Exception e){
            Console.WriteLine(e);
        }finally{
            con.Close();
        }

        return players;
    }

     public player AddNew(player p){
        MySqlConnection con=new MySqlConnection();
        
        con.ConnectionString=@"server=localhost; port=3306; user=root; password=admin123 ; database=testdb" ;
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection=con;
        cmd.CommandText = "insert into player values("+p.id+",'"+p.name+"','"+p.city+"')";
        try{
            con.Open();
            cmd.ExecuteNonQuery();

        }catch(Exception e){
            Console.WriteLine(e);
        }finally{
            con.Close();
        }

        return p;
    }

     public player Update(player p){
        MySqlConnection con=new MySqlConnection();
        
        con.ConnectionString=@"server=localhost; port=3306; user=root; password=admin123 ; database=testdb" ;
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection=con;
        cmd.CommandText = $"update player set name='{p.name}',city='{p.city}' where id={p.id}";
        try{
            con.Open();
            cmd.ExecuteNonQuery();

        }catch(Exception e){
            Console.WriteLine(e);
        }finally{
            con.Close();
        }

        return p;
     }

         public player Delete(int id){
        MySqlConnection con=new MySqlConnection();
        
        con.ConnectionString=@"server=localhost; port=3306; user=root; password=admin123 ; database=testdb" ;
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection=con;
        cmd.CommandText = $"delete from player where id={id}";
        try{
            con.Open();
            cmd.ExecuteNonQuery();

        }catch(Exception e){
            Console.WriteLine(e);
        }finally{
            con.Close();
        }

        return null;
     }
     


}