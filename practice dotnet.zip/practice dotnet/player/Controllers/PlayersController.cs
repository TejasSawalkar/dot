namespace player.Controllers;
using Microsoft.AspNetCore.Mvc;
using players.service;
using player.model;

public class PlayersController : Controller{
    private readonly IPlayerService _svc;
    public PlayersController(IPlayerService svc){
        this._svc = svc;
    }

    [HttpGet]
    public IActionResult Index(){
        List<player> players = _svc.GetAll();
        return Json(players);
    }
    [HttpPost]
    [Route("/players/add/{id:int}/{name}/{city}")]
    public IActionResult Add(int id,string name,string city){
        player p = _svc.AddNew(new player{id=id,name = name,city = city});
        return Json(p);
    }

    [HttpPut]
    [Route("/players/edit/{id:int}/{name}/{city}")]
    public IActionResult Edit(int id,string name,string city){
        player p = _svc.Update(new player{id=id,name=name,city=city});
        return Json(p);
    }

    [HttpDelete]
    public IActionResult Delete(int id){
        player p = _svc.Delete(id);
        return Json(p);
    }

}